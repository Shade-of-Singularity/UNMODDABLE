# BOOTSTRAP
BOOTSTRAP is UNMODDABLE's core - the mod loader itself.

This is a same thing what mod launchers (like Nexus and Thunderstore) put into your game automatically.

# How to install BOOTSTRAP
1. Find where UNBEATABLE is.
    1. Go to Steam -> Right click the game in the games list.
    2. Navigate to Properties... -> Installed Files -> Browse...
    - This is where mod launcher (without the mods) will be stored.
2. Put following files next to `UNBEATABLE.exe`:
    1. `.doorstop_version`.
    2. `dootstop_config.ini`
    3. `winhttp.dll`
    4. entire `BOOTSTRAP` folder.
3. Launch the game, and enter main menu.
4. `unmoddable.log` should appear next to `UNBEATABLE.exe`.

**Mods will now load automatically!**

Follow `UNMODDABLE`'s guide to install actual mods.

# Trivia
## Modding
If you want to make mods - visit project's repo:

https://github.com/Shade-of-Singularity/UNMODDABLE

Root folder for all modded content:
```
%UserProfile%/AppData/LocalLow/D-CELL GAMES/UNBEATABLE/UNMODDABLE
```

## Mods folder
All assemblies from this place are loaded.

Location:
```
%UserProfile%/AppData/LocalLow/D-CELL GAMES/UNBEATABLE/UNMODDABLE/MODS
```

## Common folder
This is a data folder, for information, which community agreed on how to share.

For examle - custom stickers from UNMODDABLE are stored in `.../COMMON/Stickers`.

Location:
```
%UserProfile%/AppData/LocalLow/D-CELL GAMES/UNBEATABLE/UNMODDABLE/COMMON
```