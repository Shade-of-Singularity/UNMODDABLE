# UNMODDABLE
UNMODDABLE - is UNBEATALBE modding system.

This `.zip` stores mods themselves and mod content.

# How to install mod content
1. Make sure you've completed the guide from `BOOTSTRAP.zip`.
2. Find where UNBEATABLE's AppData is.
    - On Windows: `%UserProfile%/AppData/LocalLow/D-CELL GAMES/UNBEATABLE`
    - On Linux: `$XDG_CONFIG_HOME/unity3d/D-CELL GAMES/UNBEATABLE`
    - On macOS, somewhere around: `~/Library/Application Support/unity.dcellgames.unbeatable`
    - Otherwise, google: `Unity {Your OS}: Application.persistentDataPath`. 
3. Put entire `UNMODDABLE` folder in there (i.e. next to `PROFILES`).

**Done!**

**Mods will now launch together with your game!**

If you suspect mods might have had issues during loading - check `unmoddable.log` for `Exception`s.

# Trivia
## Modding
If you want to make mods - visit project's repo:

https://github.com/Shade-of-Singularity/UNMODDABLE

Root folder for all modded content:
```
%UserProfile%/AppData/LocalLow/D-CELL GAMES/UNBEATABLE/UNMODDABLE
```

## Mods folder
All assemblies from this place are loaded.

Location:
```
%UserProfile%/AppData/LocalLow/D-CELL GAMES/UNBEATABLE/UNMODDABLE/MODS
```

## Common folder
This is a data folder, for information, which community agreed on how to share.

For examle - custom stickers from UNMODDABLE are stored in `.../COMMON/Stickers`.

Location:
```
%UserProfile%/AppData/LocalLow/D-CELL GAMES/UNBEATABLE/UNMODDABLE/COMMON
```